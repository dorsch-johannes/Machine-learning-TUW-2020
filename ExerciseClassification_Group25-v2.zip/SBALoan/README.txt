Please download dataset from https://www.kaggle.com/mirbektoktogaraev/should-this-loan-be-approved-or-denied and place it into data/.
