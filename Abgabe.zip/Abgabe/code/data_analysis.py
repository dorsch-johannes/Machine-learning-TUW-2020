"""Created on 2020-03-25 at 14:52.
"""
__author__ = "andreasmerckel, olgadrewitz"

import pandas as pd
import matplotlib.pyplot as plt

ny_data = pd.read_csv("new-york-city-airbnb-open-data/AB_NYC_2019.csv")
print(ny_data.isnull().sum() / 48895 * 100)
price_plot = ny_data["price"].hist(bins = 10, log = True)
price_plot.set_ylabel('Number')
price_plot.set_xlabel('Price')

plt.savefig('mytable.png')
